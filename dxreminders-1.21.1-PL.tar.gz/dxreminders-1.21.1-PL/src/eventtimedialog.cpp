/***************************************************************
 * Name:      eventtimedialog.cpp
 * Author:    David Vachulka (archdvx@dxsolutions.org)
 * Copyright: 2022
 * License:   GPL3
 **************************************************************/

#include <wx/clipbrd.h>
#include "eventtimedialog.h"
#include "dxsettings.h"
#include "dxdefs.h"

IMPLEMENT_DYNAMIC_CLASS(EventtimeDialog, wxDialog)

BEGIN_EVENT_TABLE(EventtimeDialog, wxDialog)
END_EVENT_TABLE()

EventtimeDialog::EventtimeDialog(wxWindow* parent)
: wxDialog(parent, wxID_ANY, _("Time"))
{

    wxBoxSizer *mainSizer = new wxBoxSizer(wxVERTICAL);

    m_time0 = new wxRadioButton(this, wxID_ANY, _("Current time"), wxDefaultPosition, wxDefaultSize, wxRB_GROUP);
    mainSizer->Add(m_time0);
    wxBoxSizer *box6h = new wxBoxSizer(wxHORIZONTAL);
    m_time1 = new wxRadioButton(this, wxID_ANY, _("Preset time"));
    box6h->Add(m_time1, 0, wxALIGN_CENTER_VERTICAL, 5);
    m_presetTime = new dxTimePickerCtrl(this, dxsettings.reminderPresetTime());
    box6h->Add(m_presetTime, 0, wxEXPAND|wxALL, 5);
    mainSizer->Add(box6h);
    wxBoxSizer *box6h1 = new wxBoxSizer(wxHORIZONTAL);
    m_time2 = new wxRadioButton(this, wxID_ANY, _("Minutes ahead from now"));
    box6h1->Add(m_time2, 0, wxALIGN_CENTER_VERTICAL, 5);
    m_minutes = new wxSpinCtrl(this);
    box6h1->Add(m_minutes, 0, wxEXPAND|wxALL, 5);
    mainSizer->Add(box6h1);

    wxStdDialogButtonSizer *btnSizer = new wxStdDialogButtonSizer();
    wxButton* okButton = new wxButton(this, wxID_OK, "", wxDefaultPosition, wxDefaultSize, 0);
    btnSizer->AddButton(okButton);
    btnSizer->Realize();
    mainSizer->Add(btnSizer, 0, wxALL|wxALIGN_CENTER_HORIZONTAL, 5);

    this->SetSizer(mainSizer);
    mainSizer->Fit(this);
    mainSizer->SetSizeHints(this);

    switch (dxsettings.reminderTime()) {
    case 0: m_time0->SetValue(true); break;
    case 1: m_time1->SetValue(true); break;
    default: m_time2->SetValue(true);
    }
    m_minutes->SetValue(dxsettings.reminderMinutes());
}

wxDateTime EventtimeDialog::time() const
{
    if(m_time0->GetValue())
    {
        wxDateTime date = wxDateTime::Now()+wxTimeSpan::Minute();
        date.SetSecond(0);
        return date;
    }
    else if(m_time1->GetValue())
    {
        wxDateTime date = wxDateTime::Now();
        date.SetHour(wxMin(static_cast<wxDateTime::wxDateTime_t>(23),m_presetTime->time().GetHour()));
        date.SetMinute(wxMin(static_cast<wxDateTime::wxDateTime_t>(59),m_presetTime->time().GetMinute()));
        date.SetSecond(wxMin(static_cast<wxDateTime::wxDateTime_t>(59),m_presetTime->time().GetSecond()));
        return date;
    }
    else
    {
        wxDateTime date = wxDateTime::Now()+wxTimeSpan::Minutes(m_minutes->GetValue()+1);
        date.SetSecond(0);
        return date;
    }
}
