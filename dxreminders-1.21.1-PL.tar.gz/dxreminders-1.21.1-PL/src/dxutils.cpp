/***************************************************************
 * Name:      dxutils.cpp
 * Author:    David Vachulka (archdvx@dxsolutions.org)
 * Copyright: 2020
 * License:   GPL3
 **************************************************************/

#include <wx/tokenzr.h>
#include <wx/url.h>
#include <wx/wfstream.h>
#include <wx/sstream.h>
#include "dxutils.h"
#include "data/event.h"
#include "config.h"

wxString dxutils::formatDateTime(const wxDateTime &date, const wxString &formatDate, const wxString &formatTime, int layout)
{
    struct tm t = dateTimeToTm(date);
    wxString format;
    switch (layout) {
    case 0: format << formatDate; format << " "; format << formatTime; break;
    case 1: format << formatTime; format << " "; format << formatDate; break;
    case 2: format = formatDate; break;
    default: format = formatTime;
    }
    char mbstr[100];
    if(std::strftime(mbstr, sizeof(mbstr), format.mb_str(), &t))
    {
        return mbstr;
    }
    return _("Invalid format");
}

wxString dxutils::formatDate(const wxDateTime &date, const wxString &formatDate, bool replaceBrackets)
{
    wxString format = formatDate;
    if(replaceBrackets)
    {
        format.Replace("[","");
        format.Replace("]","");
        format.Replace("(","");
        format.Replace(")","");
    }
    struct tm t = dateTimeToTm(date);
    char mbstr[100];
    if(std::strftime(mbstr, sizeof(mbstr), format.mb_str(), &t))
    {
        return mbstr;
    }
    return _("Invalid format");
}

wxString dxutils::formatTime(const wxDateTime &date, const wxString &formatTime, bool replaceBrackets)
{
    wxString format = formatTime;
    if(replaceBrackets)
    {
        format.Replace("[","");
        format.Replace("]","");
        format.Replace("(","");
        format.Replace(")","");
    }
    struct tm t = dateTimeToTm(date);
    char mbstr[100];
    if(std::strftime(mbstr, sizeof(mbstr), format.mb_str(), &t))
    {
        return mbstr;
    }
    return _("Invalid format");
}

wxDateTime dxutils::easternSunday(int year)
{
    int a = year % 19;
    int b = year / 100;
    int c = year % 100;
    int d = b / 4;
    int e = b % 4;
    int f = (b+8) / 25;
    int g = (b-f+1) / 3;
    int h = (19*a + b - d - g + 15) % 30;
    int i = c / 4;
    int k = c % 4;
    int l = (32 + 2*e + 2*i - h - k) % 7;
    int m = (a + 11*h + 22*l) / 451;
    int p = (h + l - 7*m + 114) % 31;
    return wxDateTime(static_cast<wxDateTime::wxDateTime_t>(p+1), ((h + l - 7*m + 114) / 31) == 3 ? wxDateTime::Mar : wxDateTime::Apr, year);
}

wxDateTime::wxDateTime_t dxutils::lastdayofmonth(wxDateTime::Month month, int year)
{
    switch (month) {
    case wxDateTime::Jan: return 31;
    case wxDateTime::Feb: {
        if(wxDateTime::IsLeapYear(year)) return 29;
        else return 28;
    }
    case wxDateTime::Mar: return 31;
    case wxDateTime::Apr: return 30;
    case wxDateTime::May: return 31;
    case wxDateTime::Jun: return 30;
    case wxDateTime::Jul: return 31;
    case wxDateTime::Aug: return 31;
    case wxDateTime::Sep: return 30;
    case wxDateTime::Oct: return 31;
    case wxDateTime::Nov: return 30;
    case wxDateTime::Dec: return 31;
    default: return 0;
    }
}

wxDateTime::wxDateTime_t dxutils::weeksofmonth(const wxDateTime &date)
{
    return date.GetLastMonthDay().GetWeekOfMonth();
}

wxString dxutils::fontToString(const wxFont &font)
{
    return font.GetNativeFontInfoDesc();
}

wxFont dxutils::fontFromString(const wxString &fontstr)
{
    return wxFont(fontstr);
}

tm dxutils::dateTimeToTm(const wxDateTime &date)
{
    struct tm t;
    t.tm_year = date.GetYear()-1900;
    t.tm_mon = date.GetMonth();
    t.tm_mday = date.GetDay();
    t.tm_hour = date.GetHour();
    t.tm_min = date.GetMinute();
    t.tm_sec = date.GetSecond();
    t.tm_wday = date.GetWeekDay();
    t.tm_yday = date.GetDayOfYear()-1;
    return t;
}

size_t dxutils::numberOfChars(const wxString &text, char value)
{
    size_t result = 0;
    for(size_t i=0; i<text.Len(); ++i)
    {
        if(text[i] == value) result++;
    }
    return result;
}

int dxutils::recurrenceSelectionToType(int selection)
{
    switch (selection){
    case 0: return R_NONE;
    case 1: return R_ONCENOTDELETE;
    case 2: return R_ONCE;
    case 3: return R_MINUTES;
    case 4: return R_HOURLY;
    case 5: return R_DAILY;
    case 6: return R_DAILYBUSINESS;
    case 7: return R_GIVENDAYS;
    case 8: return R_WEEKLY;
    case 9: return R_WEEKLYBUSINESS;
    case 10: return R_WEEKLYPLUSBUSINESSDAY;
    case 11: return R_WEEKLYGIVENBUSINESSDAY;
    case 12: return R_2WEEKLY;
    case 13: return R_2WEEKLYBUSINESS;
    case 14: return R_2WEEKLYPLUSBUSINESSDAY;
    case 15: return R_2WEEKLYGIVENBUSINESSDAY;
    case 16: return R_MONTHLY;
    case 17: return R_MONTHLYBUSINESS;
    case 18: return R_MONTHLYPLUSBUSINESSDAY;
    case 19: return R_MONTHLYGIVENBUSINESSDAY;
    case 20: return R_MONTHLYATDAY;
    case 21: return R_MONTHLYEND;
    case 22: return R_MONTHLYENDBUSINESS;
    case 23: return R_QUARTERLY;
    case 24: return R_QUARTERLYBUSINESS;
    case 25: return R_QUARTERLYPLUSBUSINESSDAY;
    case 26: return R_QUARTERLYGIVENBUSINESSDAY;
    case 27: return R_YEARLY;
    case 28: return R_OWN;
    default: return R_ONCE;
    }
}

int dxutils::recurrenceTypeToSelection(int type)
{
    switch (type){
    case R_ONCE: return 2;
    case R_ONCENOTDELETE: return 1;
    case R_MINUTES: return 3;
    case R_HOURLY: return 4;
    case R_DAILY: return 5;
    case R_DAILYBUSINESS: return 6;
    case R_WEEKLY: return 8;
    case R_WEEKLYBUSINESS: return 9;
    case R_WEEKLYPLUSBUSINESSDAY: return 10;
    case R_WEEKLYGIVENBUSINESSDAY: return 11;
    case R_2WEEKLY: return 12;
    case R_2WEEKLYBUSINESS: return 13;
    case R_2WEEKLYPLUSBUSINESSDAY: return 14;
    case R_2WEEKLYGIVENBUSINESSDAY: return 15;
    case R_MONTHLY: return 16;
    case R_MONTHLYBUSINESS: return 17;
    case R_MONTHLYPLUSBUSINESSDAY: return 18;
    case R_MONTHLYGIVENBUSINESSDAY: return 19;
    case R_MONTHLYATDAY: return 20;
    case R_QUARTERLY: return 23;
    case R_QUARTERLYBUSINESS: return 24;
    case R_QUARTERLYPLUSBUSINESSDAY: return 25;
    case R_QUARTERLYGIVENBUSINESSDAY: return 26;
    case R_YEARLY: return 27;
    case R_OWN: return 28;
    case R_NONE: return 0;
    case R_GIVENDAYS: return 7;
    case R_MONTHLYEND: return 21;
    case R_MONTHLYENDBUSINESS: return 22;
    default: return 0;
    }
}

wxArrayString dxutils::reminders()
{
    wxArrayString reminders;
    reminders.Add(_("At set time"));
    reminders.Add(_("5 minutes before"));
    reminders.Add(_("15 minutes before"));
    reminders.Add(_("1 hour before"));
    reminders.Add(_("2 hours before"));
    reminders.Add(_("1 day before"));
    reminders.Add(_("2 days before"));
    reminders.Add(_("Custom"));
    return reminders;
}

wxArrayString dxutils::recurrences()
{
    wxArrayString recurrences;
    recurrences.Add(_("None (Do not delete)"));
    recurrences.Add(_("Once (Do not delete)"));
    recurrences.Add(_("Once"));
    recurrences.Add(_("Minutes"));
    recurrences.Add(_("Hourly"));
    recurrences.Add(_("Daily"));
    recurrences.Add(_("Daily at business day"));
    recurrences.Add(_("Daily at given day(s)"));
    recurrences.Add(_("Weekly"));
    recurrences.Add(_("Weekly at business day"));
    recurrences.Add(_("Weekly plus given business day"));
    recurrences.Add(_("Weekly at given business day"));
    recurrences.Add(_("Fortnightly"));
    recurrences.Add(_("Fortnightly at business day"));
    recurrences.Add(_("Fortnightly plus given business day"));
    recurrences.Add(_("Fortnightly at given business day"));
    recurrences.Add(_("Monthly"));
    recurrences.Add(_("Monthly at business day"));
    recurrences.Add(_("Monthly plus given business day"));
    recurrences.Add(_("Monthly at given business day"));
    recurrences.Add(_("Monthly at given day"));
    recurrences.Add(_("Monthly at last day of month"));
    recurrences.Add(_("Monthly at last business day of month"));
    recurrences.Add(_("Quarterly"));
    recurrences.Add(_("Quarterly at business day"));
    recurrences.Add(_("Quarterly plus given business day"));
    recurrences.Add(_("Quarterly at given business day"));
    recurrences.Add(_("Yearly"));
    recurrences.Add(_("Custom"));
    return recurrences;
}

long dxutils::textToInt(const wxString &text)
{
    long result = 0;
    wxString number = "";
    for(size_t i=0; i<text.Len(); ++i)
    {
        if(std::isdigit(static_cast<unsigned char>(text[i])))
        {
            number << text[i];
        }
        else
        {
            break;
        }
    }
    if(number.Len())
    {
        number.ToLong(&result);
    }
    return result;
}

wxString dxutils::fromStdString(const std::string &str)
{
    if(str.empty()) return "";
    return wxString::FromUTF8(str.c_str());
}

wxString dxutils::availableVersion()
{
#if wxUSE_URL
    wxURL url("http://dxsolutions.org/dxreminders-version");
    if(url.GetError() != wxURL_NOERR)
    {
        return "0.00.0";
    }
    wxInputStream *data = url.GetInputStream();
    if(!data)
    {
        return "0.00.0";
    }
    if(data->IsOk())
    {
        wxString availableVersion;
        wxStringOutputStream stream(&availableVersion);
        data->Read(stream);
        delete data;
        return availableVersion;
    }
    else
    {
        delete data;
        return "0.00.0";
    }
    return "0.00.0";
#else
    return "0.00.0";
#endif
}

int dxutils::versionToInt(const wxString &version)
{
    int result = 0;
    wxStringTokenizer tok(version.BeforeFirst('-'), ".");
    if(tok.CountTokens() == 3)
    {
        int i=0;
        long a = 0;
        while(tok.HasMoreTokens())
        {
            wxString token = tok.GetNextToken();
            switch(i) {
            case 0: token.ToLong(&a); result += a*1000; break;
            case 1: token.ToLong(&a); result += a*10; break;
            case 2: token.ToLong(&a); result += a; break;
            default: break;
            }
            i++;
        }
    }
    if(version.Contains("-"))
    {
        result += 1000;
    }
    return result;
}
