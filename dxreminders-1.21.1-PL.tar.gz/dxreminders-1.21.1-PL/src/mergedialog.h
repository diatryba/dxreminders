/***************************************************************
 * Name:      mergedialog.h
 * Author:    David Vachulka (archdvx@dxsolutions.org)
 * Copyright: 2020
 * License:   GPL3
 **************************************************************/

#ifndef MERGEDIALOG_H
#define MERGEDIALOG_H

#ifndef WX_PRECOMP
    #include <wx/wx.h>
#endif
#include <wx/listctrl.h>
#include "data/engine.h"

class MergeEventsDialog: public wxDialog
{
    DECLARE_DYNAMIC_CLASS(MergeDialog)
    DECLARE_EVENT_TABLE()
public:
    MergeEventsDialog() {}
    MergeEventsDialog(wxWindow *parent);
private:
    void OnOk(wxCommandEvent& event);
    void fillMerge();

    std::vector<Event> m_mergeEvents;
    wxListCtrl *m_mergeList;
    wxPanel *m_mergePanel;
};

#endif  /* MERGEDIALOG_H */

