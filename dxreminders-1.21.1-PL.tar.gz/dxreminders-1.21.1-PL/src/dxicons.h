/***************************************************************
 * Name:      dxicons.h
 * Author:    David Vachulka (archdvx@dxsolutions.org)
 * Copyright: 2020
 * License:   GPL3
 **************************************************************/

#ifndef DXICONS_H
#define DXICONS_H

wxIcon makeIcon(const wxString &path, const wxString &name);
wxIcon makeGreyedIcon(const wxString &path, const wxString &name);
wxIcon makeScaledIcon(const wxString& path, int max=16);
void makeAllIcons(const wxString &path);

extern wxIcon ICO_ICON;
extern wxIcon ICO_TRAY;
extern wxIcon ICO_ETRAY;
extern wxIcon ICO_ABOUT;
extern wxIcon ICO_ADD;
extern wxIcon ICO_GADD;
extern wxIcon ICO_EDIT;
extern wxIcon ICO_GEDIT;
extern wxIcon ICO_DELETE;
extern wxIcon ICO_GDELETE;
extern wxIcon ICO_DATE;
extern wxIcon ICO_TIME;
extern wxIcon ICO_GTIME;
extern wxIcon ICO_CLEAR;
extern wxIcon ICO_GCLEAR;
extern wxIcon ICO_NOTE;
extern wxIcon ICO_HIDE;
extern wxIcon ICO_GHIDE;
extern wxIcon ICO_SHOW;
extern wxIcon ICO_GSHOW;
extern wxIcon ICO_HIDEALL;
extern wxIcon ICO_GHIDEALL;
extern wxIcon ICO_SHOWALL;
extern wxIcon ICO_GSHOWALL;
extern wxIcon ICO_EADD;
extern wxIcon ICO_GEADD;
extern wxIcon ICO_EEDIT;
extern wxIcon ICO_GEEDIT;
extern wxIcon ICO_EDELETE;
extern wxIcon ICO_GEDELETE;
extern wxIcon ICO_FILTER;
extern wxIcon ICO_GFILTER;
extern wxIcon ICO_FILTERCLEAR;
extern wxIcon ICO_GFILTERCLEAR;
extern wxIcon ICO_SHOWDONOTDELETE;
extern wxIcon ICO_GSHOWDONOTDELETE;
extern wxIcon ICO_ECOPY;
extern wxIcon ICO_GECOPY;


#endif // DXICONS_H
