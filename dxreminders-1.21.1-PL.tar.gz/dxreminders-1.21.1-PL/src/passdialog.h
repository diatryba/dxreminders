/***************************************************************
 * Name:      passdialog.h
 * Author:    David Vachulka (archdvx@dxsolutions.org)
 * Copyright: 2020
 * License:   GPL3
 **************************************************************/

#ifndef PASSDIALOG_H
#define PASSDIALOG_H

#ifndef WX_PRECOMP
    #include <wx/wx.h>
#endif

class PassDialog: public wxDialog
{
    DECLARE_DYNAMIC_CLASS(PassDialog)
    DECLARE_EVENT_TABLE()
public:
    PassDialog() {}
    PassDialog(wxWindow *parent);

private:
    void OnCopyto(wxCommandEvent &event);
};

#endif  /* PASSDIALOG_H */

