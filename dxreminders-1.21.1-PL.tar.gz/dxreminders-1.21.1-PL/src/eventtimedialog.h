/***************************************************************
 * Name:      eventtimedialog.h
 * Author:    David Vachulka (archdvx@dxsolutions.org)
 * Copyright: 2022
 * License:   GPL3
 **************************************************************/

#ifndef EVENTTIMEDIALOG_H
#define EVENTTIMEDIALOG_H

#ifndef WX_PRECOMP
    #include <wx/wx.h>
#endif
#include "widgets/dxtimepickerctrl.h"

class EventtimeDialog: public wxDialog
{
    DECLARE_DYNAMIC_CLASS(EventtimeDialog)
    DECLARE_EVENT_TABLE()
public:
    EventtimeDialog() {}
    EventtimeDialog(wxWindow *parent);

    wxDateTime time() const;
private:
    wxRadioButton *m_time0;
    wxRadioButton *m_time1;
    wxRadioButton *m_time2;
    dxTimePickerCtrl *m_presetTime;
    wxSpinCtrl *m_minutes;
};

#endif  /* EVENTTIMEDIALOG_H */

