/***************************************************************
 * Name:      helpdialog.h
 * Author:    David Vachulka (archdvx@dxsolutions.org)
 * Copyright: 2021
 * License:   GPL3
 **************************************************************/

#ifndef HELPDIALOG_H
#define HELPDIALOG_H

#ifndef WX_PRECOMP
    #include <wx/wx.h>
#endif
#include <wx/html/htmlwin.h>

class HelpDialog: public wxDialog
{
    DECLARE_DYNAMIC_CLASS(HelpDialog)
    DECLARE_EVENT_TABLE()
public:
    HelpDialog() {}
    HelpDialog(wxWindow *parent);
private:
    void OnLink(wxHtmlLinkEvent& event);
};

#endif  /* HELPDIALOG_H */

