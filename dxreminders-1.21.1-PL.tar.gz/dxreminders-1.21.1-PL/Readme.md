dxreminders to prosty i mały program do przypominania napisany w C++ i wxWidgets.
Aby skompilować i zainstalować program w systemie Arch Linux wystarczy uruchomić w konsoli build.sh
Strona programu:
https://dxreminders.dxsolutions.org/about.html

