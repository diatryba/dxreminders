#!/bin/bash
if find ./build
then
echo usuwam pozostałość po poprzedniej kompilacji - folder build
rm -R -f ./build/
mkdir build && cd build
cmake ..
make
sudo make install
else
mkdir build && cd build
cmake ..
make
sudo make install
fi

